package com.example.zhangyuanke.helloworld;
import android.view.View;
/**
 * Created by zhangyuanke on 2017/5/18.
 */

public interface CustomViewListener {
    public void click(View v);    //接口中唯一抽象函数,这里加不加abstract无所谓
}
