package com.example.zhangyuanke.helloworld;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

/**
 * Created by zhangyuanke on 2017/5/18.
 */

public class CustomViewLayout extends LinearLayout {

    private CustomViewListener listener;
    public CustomViewLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        LayoutInflater.from(context).inflate(R.layout.customview_layout,this);

        Button btn1 = (Button)findViewById(R.id.custom_view_button1);
        Button btn2 = (Button)findViewById(R.id.custom_view_button2);

        btn1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
//                Log.d("tag","button1");
                if (listener != null) {
                    listener.click(v);
                }
            }
        });

        btn2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.click(v);
                }
            }
        });
    }

    public void setListener(CustomViewListener listener) {
        this.listener = listener;
    }
}


