package com.example.zhangyuanke.helloworld;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.widget.FrameLayout;

import com.example.mylibrary.MyTest;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        CustomViewLayout v = (CustomViewLayout)findViewById(R.id.customView);
//        v.setListener(new CustomViewListener() {
//            @Override
//            public void click(View v) {
//                Log.d("tag", String.valueOf(v.getId()));
//            }
//        });
//        Button b = (Button) v.findViewById(R.id.custom_view_button1);
//        b.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Log.d("tag","testtest");
//            }
//        });
//        MyTest test = (MyTest)findViewById(R.id.mytest_view);
//        Log.d("tag","haha1:" + Thread.currentThread());
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                Log.d("tag","haha2:" + Thread.currentThread());
//            }
//        }).start();

//        LinearLayout ll = (LinearLayout)findViewById(R.layout.activity_main);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams
                (FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        //设置顶部,左边布局
        params.gravity= Gravity.TOP|Gravity.LEFT;

        MyTest myTest = new MyTest(this,null);
        addContentView(myTest,params);
//        Button button = new Button(this);
//        button.setText("hello btn");
////        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams()
//        addContentView(button,params);
//        ll.addView(button);

    }
}
