package com.example.mylibrary;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by zhangyuanke on 2017/5/19.
 */

public class MyTest extends LinearLayout {

    // TODO haha
    public MyTest(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

//        LayoutInflater.from(context).inflate(R.layout.mytest_layout, this);

        Button btn = new Button(context);
        btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("tag","my test click");
            }
        });
        addView(btn);

//        ImageView im = (ImageView)findViewById(R.id.imageview_test);
        ImageView im = new ImageView(context);
        im.setImageBitmap(getImageFromAssetsFile(context,"orange_pic.png"));
        addView(im);
    }

    /*
   *
           * 从Assets中读取图片
   */
    private Bitmap getImageFromAssetsFile(Context context,String fileName)
    {
        Bitmap image = null;

        AssetManager am = context.getResources().getAssets();
        try
        {
            InputStream is = am.open(fileName);
            image = BitmapFactory.decodeStream(is);
            is.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        return image;

    }

}
