package com.example.zhangyuanke.testhello;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = (TextView)findViewById(R.id.text_view);
        textView.setText("123");

        MyTest myTest = new MyTest();
        textView.setText(myTest.helloJni() +  " 10+30=" + myTest.addCalc(20,20));

    }
}
