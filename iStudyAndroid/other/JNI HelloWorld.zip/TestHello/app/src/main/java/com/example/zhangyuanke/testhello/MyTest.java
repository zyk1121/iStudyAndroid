package com.example.zhangyuanke.testhello;

/**
 * Created by zhangyuanke on 16/11/8.
 */

public class MyTest {
    private static MyTest instance;
    public MyTest() {
        super();
    }
    public static MyTest getInstance() {
        if (instance == null) {
            instance = new MyTest();
        }
        return instance;
    }
    static {
        try {
            System.loadLibrary("hello_jni");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static native String helloJni();
    public static native int addCalc(int a, int b);
}


